BUILD CHECKPOINT ONLY. This is NOT the playable game.
Contains the compiled double-precision threaded voxel backend, matching source, profile and build provenance. See BUILD_STATUS.json for remaining work.
Voxel source license GPL-3.0; see source/LICENSE.md and source/godot-cpp/LICENSE.md.
