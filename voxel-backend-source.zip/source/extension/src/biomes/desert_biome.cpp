#include "../../include/biomes/desert_biome.h"
#include "../../include/world.h"

#include <godot_cpp/core/class_db.hpp>
#include <godot_cpp/variant/utility_functions.hpp>

using namespace godot;

void DesertBiome::_bind_methods() {
    BIND_PROPERTY(DesertBiome, bool, imprecise);
}

DEFINE_CONSTRUCTORS(DesertBiome);

DEFINE_PROPERTY_GETTER_SETTER(DesertBiome, bool, imprecise);

void DesertBiome::initialize() {
    Biome::initialize();
    terrain_noise = world->generator->noise[0];
}

void DesertBiome::generate_chunk_data(Chunk* chunk, Vector3i chunk_position, Vector3i biome_coordinate) {
    uint16_t rng_seed = world->generator->seed;
    Random::scramble_rng_seed(&rng_seed, chunk_position);

    if (imprecise) chunk_position += chunk_position * Vector3i(712, 0, 325);

    const double FOLIAGE_RARE_CHANCE = 0.0015;
    const double FOLIAGE_CHANCE = 0.05;
    const double DOUBLE_FOLIAGE_CHANCE = 0.4;

    for (int64_t z = 0; z < Chunk::CHUNK_SIZE_Z; z++) {
    for (int64_t x = 0; x < Chunk::CHUNK_SIZE_X; x++) {
        int64_t ground_level = get_ground_level(chunk_position + Vector3i(x, 0, z), biome_coordinate);
        int64_t water_level = get_water_level(chunk_position + Vector3i(x, 0, z), biome_coordinate);

        for (int64_t y = 0; y < Chunk::CHUNK_SIZE_Y; y++) {
            Vector3i local_position = Vector3i(x, y, z);
            Vector3i position = chunk_position + local_position;
            Random::scramble_rng_seed(&rng_seed, position);

            if (block_locked(chunk, local_position)) {
                continue;
            }

            int32_t block_type = 0;

            if (position.y > ground_level + 2) {
                // Air
            } else if (position.y == ground_level + 2) {
                // Double cactus

                block_type = 0;
                if (position.y > water_level + beach_height + 1 && local_position.y >= 1 &&
                    Random::randf(rng_seed) < DOUBLE_FOLIAGE_CHANCE &&
                    is_foliage_safe(chunk, position, local_position) &&
                    chunk->get_block_index_at(local_position - Vector3i(0, 1, 0)) == (int) world->block_name_map["cactus block"]) {

                        block_type = world->block_name_map["cactus block"];
                }
            } else if (position.y == ground_level + 1) {
                // Foliage

                if (water_level < position.y && position.y <= water_level + beach_height + 1) {
                    // No foliage on beaches
                } else {
                    block_type = 0;

                    // Prevents foliage from spawning with no ground under it
                    if (is_foliage_safe(chunk, position, local_position)) {
                        // Pick between common/uncommon foliage
                        if (Random::randf(rng_seed) < FOLIAGE_RARE_CHANCE) {
                            block_type = position.y <= water_level ? world->block_name_map["lively seaweed foliage"] : world->block_name_map["cactus block"];
                        } else if (Random::randf(rng_seed) < FOLIAGE_CHANCE) {
                            block_type = position.y <= water_level ? world->block_name_map["seaweed foliage"] : world->block_name_map["desert grass foliage"];
                        }
                    }
                }
            } else if (position.y == ground_level || position.y == ground_level - 1) {
                // Top level of ground
                block_type = world->block_name_map["sand block"];
            } else if (position.y < ground_level && position.y > ground_level - dirt_height) {
                // Second layer of ground
                block_type = world->block_name_map["sandstone block"];
            } else {
                // Underground
                block_type = world->block_name_map["stone block"];
            }

            if (is_cave_void(position, ground_level)) {
                block_type = 0;

                // Build dams around water and chunk borders
                if (is_cave_dam(position, biome_coordinate, ground_level) || position.y <= water_level && is_on_horizontal_border(chunk, position, local_position)) {
                    block_type = world->block_name_map["sandstone block"];
                }
            }

            // Biome floor
            if (is_on_vertical_border(chunk, position, local_position)) {
                block_type = world->block_name_map["stone block"];
            }

            chunk->blocks[Chunk::position_to_index(Vector3i(x, y, z))] = block_type;
            chunk->water[Chunk::position_to_index(Vector3i(x, y, z))] = (position.y <= water_level && ground_level - water_level < DRY_CAVE_HEIGHT) ? 255 : 0;
        }
    }
    }
}

void DesertBiome::generate_decorations(Vector3i chunk_position, Vector3i biome_coordinate) {
    if (!imprecise) simple_decoration_shuffle(chunk_position, biome_coordinate, true, false);
}

int64_t DesertBiome::get_ground_level(Vector3i position, Vector3i biome_coordinate) {
    int biome_height_offset = world->generator->Y_PER_BIOME_Y * (biome_coordinate.y - 6);
    double noise = terrain_noise->get_noise_2d(position.x, position.z);
    double noise_sq = noise * noise;
    noise += noise_sq;
    return biome_height_offset + (int64_t) (96.0 * (0.425 + noise));
}